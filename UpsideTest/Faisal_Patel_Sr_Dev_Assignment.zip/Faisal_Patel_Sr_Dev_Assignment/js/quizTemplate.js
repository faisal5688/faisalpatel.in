var QUIZ = {};
QUIZ.questionCounter;
QUIZ.data = {};
QUIZ.maxOptions = 6;
QUIZ.totalQuestions;
QUIZ.quizInitialized = false;
QUIZ.questionData = {};
QUIZ.optionArr = [];
QUIZ.mainContainer;
QUIZ.prevOption;
QUIZ.userAnswer;
QUIZ.correctAnswer;
QUIZ.totCorAns;

QUIZ.initQUIZ = function(data) {
    QUIZ.data = data;
    QUIZ.mainContainer = $(".wrapper");
    QUIZ.questionCounter = -1;
    QUIZ.quizInitialized = false;
    QUIZ.totCorAns = 0;
    
    QUIZ.totalQuestions = QUIZ.data.MCQArr.length;
    QUIZ.init();    
}   

QUIZ.init = function(){
    if (QUIZ.totalQuestions <= 1)
    QUIZ.mainContainer.find("#mcssNextBtn").hide();
    QUIZ.questionData = QUIZ.data.MCQArr[0];
    QUIZ.createOptions();
    QUIZ.showNextQuestion();
    QUIZ.addListeners();
    QUIZ.chkNextEnable(false);    
}
QUIZ.showNextQuestion = function() {
    QUIZ.questionCounter++;
    QUIZ.questionData = QUIZ.data.MCQArr[QUIZ.questionCounter];
    $("#mcssSubmitBtn").show();
    $(".questNumber").html("<p><strong>"+(QUIZ.questionCounter+1)+"</strong> of " +QUIZ.totalQuestions+"</p>");
    QUIZ.disableOptions();
    QUIZ.resetQUIZ();
    QUIZ.showQuestion();
    if (QUIZ.questionCounter > 0) {
        QUIZ.quizInitialized = false;
        QUIZ.addListeners();
    };
}
QUIZ.createOptions = function() {
    //create clone options for assessment
    QUIZ.optionArr=[]
    var type = '';    
    for (var o = 0; o < QUIZ.maxOptions; o++) {     
		(QUIZ.questionData.answer.length == 1) ? (type = "mcss") : (type = "mcms");
        var option = $(QUIZ.mainContainer.find("#mcssOptionContainer").find(".cloneOption")).clone();
        option.removeClass("cloneOption");        
        if (type == "mcss") {
            option.find('#optionBox').addClass('radio').removeClass('checkBox');
            var opt = new Option(option, "mcss", o);
            //console.log("mcss")
        } else {
            option.find('#optionBox').addClass('checkBox').removeClass('radio');
            var opt = new Option(option, "mcms", o);
            //console.log("mcss")
        } 
        QUIZ.optionArr.push(opt);
        eventMgr.addControlEventListener(opt.holder, "optionClicked", QUIZ.mcssOptionClicked);
        QUIZ.mainContainer.find("#mcssOptionContainer").append(opt.holder)
    }
};

QUIZ.addListeners = function() {
    //addlisteners to buttons	
    if (!QUIZ.quizInitialized) {
        QUIZ.quizInitialized = true;
        for (var o = 1; o <= QUIZ.optionArr.length; o++) {
            var option = QUIZ.optionArr[o - 1];
            option.addListeners();
        }
    };
    $("#mcssContainer").find("#mcssNextBtn").off().on("click",QUIZ.nextClicked);
};

QUIZ.showQuestion = function() {
    QUIZ.initializeQUIZ();
};

/*QUIZ functionality*/
QUIZ.initializeQUIZ = function() {
    QUIZ.createOptions()
    QUIZ.userAnswer = [];
    QUIZ.correctAnswer = [];
    $("#mcssContainer").find("#mcssQuestionTxt").html(QUIZ.questionData.questiontext);
    $("#mcssContainer").find(".Instruction").html(QUIZ.questionData.instructionText);
    QUIZ.correctAnswer = QUIZ.questionData.answer;
    $("#mcssContainer").find(".mcssOption").addClass("hiddenOption");
    $("#mcssContainer #questionCount").html(QUIZ.questionCounter + 1 + " of " + QUIZ.totalQuestions);    
    for (c = 0; c < QUIZ.questionData.options.length; c++) {
        var option = QUIZ.optionArr[c];
        option.showOption(QUIZ.questionData.options[c].text);
    }
}

QUIZ.resetQUIZ = function() {
    QUIZ.userAnswer = [];
    QUIZ.prevOption = null;
    for (c = 0; c < QUIZ.questionData.options.length; c++) {
        var option = QUIZ.optionArr[c];
        option.reset();
    }
    $("#feedbackContent").removeClass("Correct").removeClass("Incorrect");
    $("#mcssOptionContainer .radio").removeClass("Correct").removeClass("Incorrect");

}

QUIZ.mcssOptionClicked = function(evt) {
    var clicked = $(evt.target).parent().parent();
    if (QUIZ.prevOption) {
        
        QUIZ.prevOption.find("#optionBox").removeClass("MCSSbulletPointsSelected");
    }
    QUIZ.prevOption = clicked;
    var str = clicked.attr("id");
    //answer for mcq/mrq 
    if(QUIZ.questionData.answer.length == 1){
        QUIZ.userAnswer.push(parseInt(str.split("_")[1]))
    }else{
        if (clicked.find("#optionBox").hasClass("MCMSbulletPointsSelected")) {
			QUIZ.userAnswer.push(parseInt(str.split("_")[1]));
		} else {
            for( var i = 0; i < QUIZ.userAnswer.length; i++){    
                if ( QUIZ.userAnswer[i] === parseInt(str.split("_")[1])) {             
                    QUIZ.userAnswer.splice(i, 1); 
                }
            
            }
		}
    }
    if(QUIZ.userAnswer.length<1){
        QUIZ.chkNextEnable(false);
        
    }else{
        QUIZ.chkNextEnable(true);
    }
    
}


QUIZ.nextClicked = function(evt) {    
    QUIZ.chkUserAnswer(); //update cur question status
    if (QUIZ.questionCounter < QUIZ.totalQuestions - 1) {
        QUIZ.showNextQuestion(); //show next question        
    } else {
        
    }
}

QUIZ.disableOptions = function() {
    for (var c = 1; c <= QUIZ.maxOptions; c++) {
        var option = QUIZ.optionArr[c - 1];
        option.disable();
    }
}

QUIZ.chkUserAnswer = function() {
    var tempArr = [];
    tempArr = QUIZ.correctAnswer.concat();
    for (var c = 0; c < QUIZ.userAnswer.length; c++) {
        var ind = jQuery.inArray(QUIZ.userAnswer[c], tempArr);
        if (ind >= 0)
            tempArr.splice(ind, 1);
    }
    var result = "Incorrect";
    QUIZ.chkNextEnable(false)
    if (tempArr.length <= 0 && (QUIZ.correctAnswer.length ==QUIZ.userAnswer.length)) {
        result = 'Correct';
        QUIZ.chkNextEnable(true);
        QUIZ.totCorAns++;
    }
    if(QUIZ.questionCounter == (QUIZ.totalQuestions - 1)){        
        $("#mcssBox").hide();
        $("#mcssResultBox").show();
        $(".resultImagBackground").removeClass("pass fail");
        $("#mcssTryAgainBtn").show();
        $("#mcssContainer").find("#mcssTryAgainBtn").off().on("click",QUIZ.tryAgainClicked);
        var score = QUIZ.percentage(QUIZ.totCorAns,QUIZ.totalQuestions);        
        if(score>=QUIZ.data.passingScore){
            $(".resultText").html("").html("<strong>Well done!</strong><br>You got <strong>"+QUIZ.totCorAns+" out of "+QUIZ.totalQuestions+"</strong> questions right!");
            $(".resultInstruction").html("").html("Looks like you'll be a strong link in the information security chain!");
            $(".resultImagBackground").addClass("pass");
            //$("#mcssTryAgainBtn").hide();
        }else{
            $(".resultText").html("").html("You got <strong>"+QUIZ.totCorAns+" out of "+QUIZ.totalQuestions+"</strong> questions right!");
            $(".resultInstruction").html("").html("Go through the content again, and have another try...");
            //$("#mcssTryAgainBtn").show();
            $(".resultImagBackground").addClass("fail");
            
        }
    };
};

QUIZ.chkNextEnable=function(flag){
	if(flag){
		$("#mcssContainer").find("#mcssNextBtn").removeClass("disabled").addClass("submitButton");
	}else{
		$("#mcssContainer").find("#mcssNextBtn").removeClass("submitButton").addClass("disabled");
	}
};

QUIZ.percentage = function(score, total)
{
  return (score/total)*100;
}

QUIZ.tryAgainClicked = function() {
    QUIZ.userAnswer = [];
    QUIZ.prevOption = null;
    for (c = 0; c < QUIZ.questionData.options.length; c++) {
        var option = QUIZ.optionArr[c];
        option.reset();
    }
    $("#feedbackContent").removeClass("Correct").removeClass("Incorrect");
    $("#mcssOptionContainer .radio").removeClass("Correct").removeClass("Incorrect");
    $("#mcssBox").show();
    $("#mcssResultBox").hide();
    $(".resultImagBackground").removeClass("pass fail")
    QUIZ.questionCounter = -1;
    QUIZ.quizInitialized = false;
    QUIZ.totCorAns = 0;
    QUIZ.init();
}


var EventManager = function(){
	//trace(":: Event Manager Loaded ::");
	
	this.dispatchCustomEvent = function(controlName, eventName, isBubbling, dataObj){
		//trace("***** Event Dispatched *****");
		$(eval(controlName)).trigger(
				{
					type:eventName,
					obj:dataObj
				}, isBubbling);
	}
	
	this.addControlEventListener = function(controlName, eventName, callBackFn){
		//trace("***** Event Added *****");
		//trace(controlName + " : " + eventName);
		$(controlName).bind(eventName, callBackFn);		
	}
	
	this.removeControlEventListener = function(controlName, eventName, callBackFn){
		//trace("***** Event Removed *****");
		$(controlName).unbind(eventName, callBackFn);
	}
}
eventMgr = new EventManager();

