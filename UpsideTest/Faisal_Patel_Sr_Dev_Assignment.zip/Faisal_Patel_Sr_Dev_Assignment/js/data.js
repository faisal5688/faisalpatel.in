var quizData = [{	
	passingScore:80,
	MCQArr: [
		{
			type: "mcq",		
			questiontext: "What's the difference between social engineering and phishing?",
			instructionText: "Select the best answer.",
			answer: [3], //[1] for mcq, [1,2] for mrq.
			options: [
				{ iscorrect: false, text: "There is no difference; both social engineering and phishing attempt to gain people’s confidence and them trick them into providing personal information which is then used for harmful purposes." },
				{ iscorrect: false, text: "Social engineering is a special type of phishing that capitalizes on people's tendency to trust and want to be helpful."},
				{ iscorrect: false, text: "Phishing is always done through an email; a phishing email can be a step within a carefully engineered social engineering attack."}
			]
			
		},
		{
			type: "mcq",
			questiontext: "Which of this is a type of physical information security threat?",
			instructionText: "Select the best answer.",
			answer: [2], //[1] for mcq, [1,2] for mrq.
			options: [
				{ iscorrect: false, text: "Baiting" },
				{ iscorrect: false, text: "Unauthorized access" },
				{ iscorrect: false, text: "Diversion thef" },
				{ iscorrect: false, text: "Pretexting" }
			]
		},
		{
			type: "mrq",
			questiontext: "Which of these could point to a potential phishing attack?",
			instructionText: "Select all that apply.",
			answer: [1,3], //[1] for mcq, [1,2] for mrq.
			options: [
				{ iscorrect: false, text: "An email from an unknown person who seeks your bank account number to correct a system error."},
				{ iscorrect: false, text: "A phone call from a pizza joint seeking to confirm your address for a delivery."},
				{ iscorrect: false, text: "An instant message from a friend of a friend that offers you the choice of registering for what seems to be the perfect holiday."},
				{ iscorrect: false, text: "A known member of the IT department coming to take away your laptop for scheduled maintenance."}
			]
		},
		{
			type: "mcq",
			questiontext: "Which of these would you qualify as suspicious, from information security point of view?",
			instructionText: "Select the best answer.",
			answer: [2], //[1] for mcq, [1,2] for mrq.
			options: [
				{ iscorrect: false, text: "An unknown person without any Visitor tag being escorted around the office by the CEO's Personal Assistant."},
				{ iscorrect: false, text: "A request from your bank to change your password for online banking that the bank's call center doesn't seem able to explain."},
				{ iscorrect: false, text: "Yet ANOTHER joke from your brother that he says you absolutely MUST forward to all your colleagues in the department."},
				{ iscorrect: false, text: "A bunch of employee files marked Confidential in front of the HR Manager, on his desk."}
			]
		},
		{
			type: "mrq",
			questiontext: "Which of these could point to a potential phishing attack?",
			instructionText: "Select all that apply.",
			answer: [1,3], //[1] for mcq, [1,2] for mrq.
			options: [
				{ iscorrect: false, text: "An email from an unknown person who seeks your bank account number to correct a system error." },
				{ iscorrect: false, text: "A phone call from a pizza joint seeking to confirm your address for a delivery." },
				{ iscorrect: false, text: "An instant message from a friend of a friend that offers you the choice of registering for what seems to be the perfect holiday." },
				{ iscorrect: false, text: "A known member of the IT department coming to take away your laptop for scheduled maintenance." }
			]
		}
	]
}];
