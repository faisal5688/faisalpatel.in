var quiz_template = (function () {    
    this.init = function (data) {
        var _aData = data;
        var _quiz = QUIZ
		_quiz.initQUIZ(_aData);
       
    };
    return this;

});

$(document).ready(function(){
    var _quizTemplate = new quiz_template();
    _quizTemplate.init(quizData[0])
});