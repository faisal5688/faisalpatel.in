var Option = function(obj,typ,id){
	this.holder = obj;
	this.type = typ;
	this.ID = id+1;
	this.holder.addClass("mcssOption");
	this.holder.addClass("hiddenOption");
	this.holder.attr("id","mcOption_"+this.ID);	
	this.holder.find("#tickCross").hide();	
	this.addListeners = function(){							
		this.resetTickCross();
		if(this.type=="mcss"){
			this.holder.find("#optionBox").removeClass("QUIZbulletPointsDisable");		
		}
		else{			
			this.holder.find("#optionBox").removeClass("MCMSBulletPointsDisabled");		
		}
		this.holder.find("#optionBox").attr("type",this.type);
		
		
		this.holder.find("#optionBox").off('click').on("click",function(e){
			e.preventDefault();
			e.stopPropagation();
			//debugger;
			var clicked = $(this).parent().parent();
			if($(this).hasClass("MCSSbulletPointsSelected"))
				return;
			// if($(this).hasClass("MCMSbulletPointsSelected"))
			// 	return;
			if($(this).attr("type")=="mcss"){					
				$(".optionText").removeClass("selected");			
				$(this).addClass("MCSSbulletPointsSelected");
				clicked.find(".optionText").addClass("selected");
			}
			else{
				//$(".optionText").removeClass("selected");
				if($(this).hasClass("MCMSbulletPointsSelected")){
					$(this).removeClass("MCMSbulletPointsSelected")
					clicked.find(".optionText").removeClass("selected");
				}else{
					$(this).addClass("MCMSbulletPointsSelected")
					clicked.find(".optionText").addClass("selected");
				}
			}
			//trigger event
			$(this).trigger({
				type:"optionClicked",
				value:this.id
			});
		});

		this.holder.off('click').on("click",function(e){
			e.preventDefault();
			//debugger;
			console.log("mcssOption")
			$(this).find("#optionBox").trigger("click");
			
		});
	}
	
	this.showOption=function(txt){
		this.holder.removeClass("hiddenOption");
		if(this.type=="mcss"){
			this.holder.find("#optionBox").removeClass("MCSSbulletPointsSelected");
			//$(".optionText").removeClass("selected");
		}else{
			this.holder.find("#optionBox").removeClass("MCMSbulletPointsSelected");
			//$(".optionText").removeClass("selected");
		}			
		this.holder.find("#optionTxt").html(txt);
	}

	this.resetTickCross=function(){
		this.holder.find("#tickCross").hide();
		this.holder.find("#tickCross").removeClass("mcssCross").removeClass("mcssTick");
	}	
	
	this.disable=function(){
		
		if(this.type=="mcss")
			this.holder.find("#optionBox").addClass("QUIZbulletPointsDisable")		
		else
			this.holder.find("#optionBox").addClass("MCMSBulletPointsDisabled")		
		this.holder.find("#optionBox").unbind();
	}
	
	this.reset=function(){
		let _optionBox = this.holder.find("#optionBox");
		_optionBox.removeClass("Correct");
		_optionBox.removeClass("Incorrect")
		//$(".optionText").removeClass("selected");
		if(this.type=="mcss")
			_optionBox.removeClass("MCSSbulletPointsSelected");	
		else
			_optionBox.removeClass("MCMSbulletPointsSelected");	
	}
};